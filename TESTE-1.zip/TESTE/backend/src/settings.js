import { db } from "./db.js";

export function setupSettingsRoutes(app, authenticateToken) {
  app.get("/api/settings", authenticateToken, (req, res) => {
    db.get("SELECT * FROM settings WHERE id = 1", (err, row) => {
      if (err) {
        console.error("Erro ao buscar configurações:", err);
        return res.status(500).json({ message: "Erro ao buscar configurações" });
      }
      res.json(row);
    });
  });

  function dbAll(sql, params = []) {
    return new Promise((resolve, reject) => {
      db.all(sql, params, (err, rows) => {
        if (err) return reject(err);
        resolve(rows || []);
      });
    });
  }

  function dbRun(sql, params = []) {
    return new Promise((resolve, reject) => {
      db.run(sql, params, function (err) {
        if (err) return reject(err);
        resolve(this);
      });
    });
  }

  app.put("/api/settings", authenticateToken, (req, res) => {
    if (!req.user || req.user.role !== "admin") {
      return res.status(403).json({ message: "Apenas administradores podem alterar configurações" });
    }
    const { interest_mode, daily_late_fee_percent, fixed_late_fee, cutoff_hour } = req.body;
    db.run(
      `
      UPDATE settings
      SET interest_mode = ?, daily_late_fee_percent = ?, fixed_late_fee = ?, cutoff_hour = ?
      WHERE id = 1
    `,
      [interest_mode, daily_late_fee_percent, fixed_late_fee, cutoff_hour],
      function (err) {
        if (err) {
          console.error("Erro ao atualizar configurações:", err);
          return res.status(500).json({ message: "Erro ao atualizar configurações" });
        }
        res.json({ message: "Configurações atualizadas" });
      }
    );
  });

  app.get("/api/settings/backup/export", authenticateToken, async (req, res) => {
    if (!req.user || req.user.role !== "admin") {
      return res.status(403).json({ message: "Apenas administradores podem exportar backup" });
    }
    try {
      const [users, clients, loans, installments, settings] = await Promise.all([
        dbAll("SELECT * FROM users"),
        dbAll("SELECT * FROM clients"),
        dbAll("SELECT * FROM loans"),
        dbAll("SELECT * FROM installments"),
        dbAll("SELECT * FROM settings")
      ]);
      res.json({
        version: 1,
        generated_at: new Date().toISOString(),
        data: { users, clients, loans, installments, settings }
      });
    } catch (err) {
      console.error("Erro ao exportar backup:", err);
      res.status(500).json({ message: "Erro ao exportar backup" });
    }
  });

  app.post("/api/settings/backup/import", authenticateToken, async (req, res) => {
    if (!req.user || req.user.role !== "admin") {
      return res.status(403).json({ message: "Apenas administradores podem importar backup" });
    }
    const payload = req.body;
    if (!payload || !payload.data) {
      return res.status(400).json({ message: "Backup inválido" });
    }
    const { users = [], clients = [], loans = [], installments = [], settings = [] } = payload.data;
    try {
      await dbRun("BEGIN");
      await dbRun("DELETE FROM installments");
      await dbRun("DELETE FROM loans");
      await dbRun("DELETE FROM clients");
      await dbRun("DELETE FROM users");
      await dbRun("DELETE FROM settings");

      for (const u of users) {
        await dbRun(
          `
          INSERT INTO users (id, name, email, password_hash, role, created_at)
          VALUES (?, ?, ?, ?, ?, ?)
        `,
          [u.id, u.name, u.email, u.password_hash, u.role, u.created_at]
        );
      }
      for (const c of clients) {
        await dbRun(
          `
          INSERT INTO clients (id, name, document, phone, address, notes, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `,
          [c.id, c.name, c.document, c.phone, c.address, c.notes, c.created_at, c.updated_at]
        );
      }
      for (const l of loans) {
        await dbRun(
          `
          INSERT INTO loans (
            id, client_id, principal, interest_type, interest_rate, installments_count,
            installment_value, start_date, status, config_json, created_at, updated_at
          )
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
          [
            l.id,
            l.client_id,
            l.principal,
            l.interest_type,
            l.interest_rate,
            l.installments_count,
            l.installment_value,
            l.start_date,
            l.status,
            l.config_json,
            l.created_at,
            l.updated_at
          ]
        );
      }
      for (const i of installments) {
        await dbRun(
          `
          INSERT INTO installments (
            id, loan_id, number, due_date, original_amount, interest_amount, penalty_amount,
            paid_amount, status, paid_at, notes, created_at, updated_at
          )
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
          [
            i.id,
            i.loan_id,
            i.number,
            i.due_date,
            i.original_amount,
            i.interest_amount,
            i.penalty_amount,
            i.paid_amount,
            i.status,
            i.paid_at,
            i.notes,
            i.created_at,
            i.updated_at
          ]
        );
      }
      for (const s of settings) {
        await dbRun(
          `
          INSERT INTO settings (id, interest_mode, daily_late_fee_percent, fixed_late_fee, cutoff_hour)
          VALUES (?, ?, ?, ?, ?)
        `,
          [s.id, s.interest_mode, s.daily_late_fee_percent, s.fixed_late_fee, s.cutoff_hour]
        );
      }
      await dbRun("COMMIT");
      res.json({ message: "Backup importado com sucesso" });
    } catch (err) {
      console.error("Erro ao importar backup:", err);
      try {
        await dbRun("ROLLBACK");
      } catch {}
      res.status(500).json({ message: "Erro ao importar backup" });
    }
  });
}
