import { db } from "./db.js";

export function addHistoryLog({ userId, entityType, entityId, action, beforeData, afterData, notes }) {
  const createdAt = new Date().toISOString();
  db.run(
    `
    INSERT INTO history_logs (user_id, entity_type, entity_id, action, before_data, after_data, notes, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `,
    [
      userId || null,
      entityType,
      entityId,
      action,
      beforeData ? JSON.stringify(beforeData) : null,
      afterData ? JSON.stringify(afterData) : null,
      notes || null,
      createdAt
    ]
  );
}

export function setupHistoryRoutes(app, authenticateToken) {
  app.get("/api/history", authenticateToken, (req, res) => {
    const { entityType, entityId } = req.query;
    const params = [];
    let where = "";
    if (entityType) {
      where += " AND entity_type = ?";
      params.push(entityType);
    }
    if (entityId) {
      where += " AND entity_id = ?";
      params.push(Number(entityId));
    }
    db.all(
      `
      SELECT h.*, u.name as user_name
      FROM history_logs h
      LEFT JOIN users u ON u.id = h.user_id
      WHERE 1=1 ${where}
      ORDER BY h.created_at DESC
      LIMIT 200
    `,
      params,
      (err, rows) => {
        if (err) {
          console.error("Erro ao buscar histórico:", err);
          return res.status(500).json({ message: "Erro ao buscar histórico" });
        }
        res.json(rows);
      }
    );
  });

  app.get("/api/history/client/:id", authenticateToken, (req, res) => {
    const clientId = Number(req.params.id);
    db.all(
      `
      SELECT h.*, u.name as user_name
      FROM history_logs h
      LEFT JOIN users u ON u.id = h.user_id
      WHERE
        (h.entity_type = 'client' AND h.entity_id = ?)
        OR (h.entity_type = 'loan' AND h.entity_id IN (SELECT id FROM loans WHERE client_id = ?))
        OR (h.entity_type = 'installment' AND h.entity_id IN (
          SELECT i.id FROM installments i JOIN loans l ON l.id = i.loan_id WHERE l.client_id = ?
        ))
      ORDER BY h.created_at DESC
      LIMIT 500
    `,
      [clientId, clientId, clientId],
      (err, rows) => {
        if (err) {
          console.error("Erro ao buscar histórico do cliente:", err);
          return res.status(500).json({ message: "Erro ao buscar histórico" });
        }
        res.json(rows);
      }
    );
  });
}
