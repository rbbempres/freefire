import { db } from "./db.js";
import { addHistoryLog } from "./history.js";

function getDaysByType(type) {
  if (type === "diario") return 1;
  if (type === "semanal") return 7;
  if (type === "quinzenal") return 15;
  return 29;
}

function calculateInstallmentDates(startDate, count, interestType) {
  const dates = [];
  const base = new Date(startDate);
  const days = getDaysByType(interestType);
  for (let i = 0; i < count; i++) {
    const d = new Date(base);
    d.setDate(d.getDate() + days * i);
    dates.push(d.toISOString().slice(0, 10));
  }
  return dates;
}

export function setupLoanRoutes(app, authenticateToken) {
  app.get("/api/loans", authenticateToken, (req, res) => {
    const { status, clientId } = req.query;
    const todayParam = new Date().toISOString().slice(0, 10);
    function runQuery(cutoffHour) {
      const conditions = ["1=1"];
      const params = [];
      if (status === "Atrasado") {
        let op = "<";
        if (typeof cutoffHour === "string") {
          const [hh = "18", mm = "00"] = cutoffHour.split(":");
          const cutoffMinutes = Number(hh) * 60 + Number(mm);
          const now = new Date();
          const nowMinutes = now.getHours() * 60 + now.getMinutes();
          op = nowMinutes >= cutoffMinutes ? "<=" : "<";
        }
        conditions.push(
          `EXISTS (SELECT 1 FROM installments i WHERE i.loan_id = l.id AND i.status != 'Pago' AND i.due_date ${op} ?)`
        );
        params.push(todayParam);
      } else if (status === "Quitado") {
        conditions.push(
          `NOT EXISTS (SELECT 1 FROM installments i WHERE i.loan_id = l.id AND i.status != 'Pago')`
        );
      } else if (status) {
        conditions.push("l.status = ?");
        params.push(status);
      }
      if (clientId) {
        conditions.push("l.client_id = ?");
        params.push(Number(clientId));
      }
      const sql = `
        SELECT l.*, c.name as client_name
        FROM loans l
        JOIN clients c ON c.id = l.client_id
        WHERE ${conditions.join(" AND ")}
        ORDER BY l.created_at DESC
      `;
      db.all(sql, params, (err, rows) => {
        if (err) {
          console.error("Erro ao listar empréstimos:", err);
          return res.status(500).json({ message: "Erro ao listar empréstimos" });
        }
        res.json(rows);
      });
    }
    if (status === "Atrasado") {
      db.get("SELECT cutoff_hour FROM settings WHERE id = 1", (err, row) => {
        const cutoffHour = err ? "18:00" : (row && row.cutoff_hour) ? row.cutoff_hour : "18:00";
        runQuery(cutoffHour);
      });
    } else {
      runQuery(null);
    }
  });

  app.post("/api/loans", authenticateToken, (req, res) => {
    const {
      client_id,
      principal,
      interest_type,
      interest_rate,
      installments_count,
      installment_value,
      start_date,
      status,
      config,
      installment_dates
    } = req.body;
    if (!client_id || !principal || !interest_type || !interest_rate || !installments_count || !start_date) {
      return res.status(400).json({ message: "Campos obrigatórios ausentes" });
    }
    const now = new Date().toISOString();
    const effectiveInstallmentValue = installment_value || principal / installments_count;
    const configJson = config ? JSON.stringify(config) : null;
    db.run(
      `
      INSERT INTO loans (
        client_id, principal, interest_type, interest_rate, installments_count,
        installment_value, start_date, status, config_json, created_at, updated_at
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,
      [
        client_id,
        principal,
        interest_type,
        interest_rate,
        installments_count,
        effectiveInstallmentValue,
        start_date,
        status || "Ativo",
        configJson,
        now,
        now
      ],
      function (err) {
        if (err) {
          console.error("Erro ao criar empréstimo:", err);
          return res.status(500).json({ message: "Erro ao criar empréstimo" });
        }
        const loanId = this.lastID;
        let dates = null;
        if (
          Array.isArray(installment_dates) &&
          installment_dates.length === installments_count &&
          installment_dates.every((d) => typeof d === "string" && /^\d{4}-\d{2}-\d{2}$/.test(d))
        ) {
          dates = installment_dates;
        } else {
          dates = calculateInstallmentDates(start_date, installments_count, interest_type);
        }
        const stmt = db.prepare(
          `
          INSERT INTO installments (
            loan_id, number, due_date, original_amount, interest_amount,
            penalty_amount, paid_amount, status, created_at, updated_at
          )
          VALUES (?, ?, ?, ?, 0, 0, 0, 'Em aberto', ?, ?)
        `
        );
        for (let i = 0; i < installments_count; i++) {
          stmt.run(loanId, i + 1, dates[i], effectiveInstallmentValue, now, now);
        }
        stmt.finalize();
        addHistoryLog({
          userId: req.user.id,
          entityType: "loan",
          entityId: loanId,
          action: "create",
          beforeData: null,
          afterData: {
            client_id,
            principal,
            interest_type,
            interest_rate,
            installments_count,
            installment_value: effectiveInstallmentValue,
            start_date,
            status: status || "Ativo",
            config
          },
          notes: null
        });
        res.status(201).json({
          id: loanId,
          client_id,
          principal,
          interest_type,
          interest_rate,
          installments_count,
          installment_value: effectiveInstallmentValue,
          start_date,
          status: status || "Ativo",
          config
        });
      }
    );
  });

  app.get("/api/loans/:id", authenticateToken, (req, res) => {
    const id = Number(req.params.id);
    db.get(
      `
      SELECT l.*, c.name as client_name
      FROM loans l
      JOIN clients c ON c.id = l.client_id
      WHERE l.id = ?
    `,
      [id],
      (err, loan) => {
        if (err) {
          console.error("Erro ao buscar empréstimo:", err);
          return res.status(500).json({ message: "Erro ao buscar empréstimo" });
        }
        if (!loan) {
          return res.status(404).json({ message: "Empréstimo não encontrado" });
        }
        db.all(
          `
          SELECT * FROM installments
          WHERE loan_id = ?
          ORDER BY due_date ASC
        `,
          [id],
          (instErr, installments) => {
            if (instErr) {
              console.error("Erro ao buscar parcelas:", instErr);
              return res.status(500).json({ message: "Erro ao buscar parcelas" });
            }
            res.json({ loan, installments });
          }
        );
      }
    );
  });

  app.put("/api/loans/:id", authenticateToken, (req, res) => {
    const id = Number(req.params.id);
    db.get("SELECT * FROM loans WHERE id = ?", [id], (err, loan) => {
      if (err) {
        console.error("Erro ao buscar empréstimo:", err);
        return res.status(500).json({ message: "Erro ao buscar empréstimo" });
      }
      if (!loan) {
        return res.status(404).json({ message: "Empréstimo não encontrado" });
      }
      const {
        principal,
        interest_type,
        interest_rate,
        installments_count,
        installment_value,
        start_date,
        status,
        config
      } = req.body;
      const now = new Date().toISOString();
      const newConfigJson = config ? JSON.stringify(config) : loan.config_json;
      db.run(
        `
        UPDATE loans
        SET principal = ?, interest_type = ?, interest_rate = ?, installments_count = ?,
            installment_value = ?, start_date = ?, status = ?, config_json = ?, updated_at = ?
        WHERE id = ?
      `,
        [
          principal ?? loan.principal,
          interest_type ?? loan.interest_type,
          interest_rate ?? loan.interest_rate,
          installments_count ?? loan.installments_count,
          installment_value ?? loan.installment_value,
          start_date ?? loan.start_date,
          status ?? loan.status,
          newConfigJson,
          now,
          id
        ],
        function (updateErr) {
          if (updateErr) {
            console.error("Erro ao atualizar empréstimo:", updateErr);
            return res.status(500).json({ message: "Erro ao atualizar empréstimo" });
          }
          addHistoryLog({
            userId: req.user.id,
            entityType: "loan",
            entityId: id,
            action: "update",
            beforeData: loan,
            afterData: {
              principal,
              interest_type,
              interest_rate,
              installments_count,
              installment_value,
              start_date,
              status,
              config
            },
            notes: null
          });
          res.json({ message: "Empréstimo atualizado" });
        }
      );
    });
  });

  app.delete("/api/loans/:id", authenticateToken, (req, res) => {
    const id = Number(req.params.id);
    db.get("SELECT * FROM loans WHERE id = ?", [id], (err, loan) => {
      if (err) {
        console.error("Erro ao buscar empréstimo:", err);
        return res.status(500).json({ message: "Erro ao buscar empréstimo" });
      }
      if (!loan) {
        return res.status(404).json({ message: "Empréstimo não encontrado" });
      }
      db.run("DELETE FROM installments WHERE loan_id = ?", [id], (instErr) => {
        if (instErr) {
          console.error("Erro ao excluir parcelas:", instErr);
        }
        db.run("DELETE FROM loans WHERE id = ?", [id], function (deleteErr) {
          if (deleteErr) {
            console.error("Erro ao excluir empréstimo:", deleteErr);
            return res.status(500).json({ message: "Erro ao excluir empréstimo" });
          }
          addHistoryLog({
            userId: req.user.id,
            entityType: "loan",
            entityId: id,
            action: "delete",
            beforeData: loan,
            afterData: null,
            notes: null
          });
          res.status(204).end();
        });
      });
    });
  });
}
