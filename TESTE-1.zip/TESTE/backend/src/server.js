import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import { db, initDatabase } from "./db.js";
import { setupAuthRoutes, authenticateToken, authorizeRole } from "./auth.js";
import { setupClientRoutes } from "./clients.js";
import { setupLoanRoutes } from "./loans.js";
import { setupInstallmentRoutes } from "./installments.js";
import { setupSettingsRoutes } from "./settings.js";
import { setupDashboardRoutes } from "./dashboard.js";
import { setupHistoryRoutes } from "./history.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 4000;

initDatabase();

app.use(cors());
app.use(express.json());

setupAuthRoutes(app);
setupClientRoutes(app, authenticateToken);
setupLoanRoutes(app, authenticateToken);
setupInstallmentRoutes(app, authenticateToken);
setupSettingsRoutes(app, authenticateToken);
setupDashboardRoutes(app, authenticateToken);
setupHistoryRoutes(app, authenticateToken);

app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

const staticPath = path.join(__dirname, "..", "public");
app.use(express.static(staticPath));

app.use((err, req, res, next) => {
  console.error("Erro inesperado:", err);
  res.status(500).json({ message: "Erro interno do servidor" });
});

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});

