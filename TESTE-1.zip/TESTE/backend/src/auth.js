import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { db } from "./db.js";

const JWT_SECRET = "changeme-secret";
const JWT_EXPIRES_IN = "8h";

export function authenticateToken(req, res, next) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];
  if (!token) {
    return res.status(401).json({ message: "Token não informado" });
  }
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ message: "Token inválido" });
    }
    req.user = user;
    next();
  });
}

export function authorizeRole(requiredRole) {
  return (req, res, next) => {
    if (!req.user || (req.user.role !== requiredRole && req.user.role !== "admin")) {
      return res.status(403).json({ message: "Acesso negado" });
    }
    next();
  };
}

export function setupAuthRoutes(app) {
  app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ message: "Email e senha são obrigatórios" });
    }
    db.get("SELECT * FROM users WHERE email = ?", [email], (err, user) => {
      if (err) {
        console.error("Erro ao buscar usuário:", err);
        return res.status(500).json({ message: "Erro interno" });
      }
      if (!user) {
        return res.status(401).json({ message: "Credenciais inválidas" });
      }
      const valid = bcrypt.compareSync(password, user.password_hash);
      if (!valid) {
        return res.status(401).json({ message: "Credenciais inválidas" });
      }
      const token = jwt.sign(
        { id: user.id, name: user.name, email: user.email, role: user.role, plan_days: user.plan_days },
        JWT_SECRET,
        { expiresIn: JWT_EXPIRES_IN }
      );
      res.json({
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          plan_days: user.plan_days
        }
      });
    });
  });
}
