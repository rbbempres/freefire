import { db } from "./db.js";
import { addHistoryLog } from "./history.js";

function parseDueDateLocal(dueDateStr) {
  if (!dueDateStr) return null;
  const [yyyy, mm, dd] = String(dueDateStr).split("-").map((v) => Number(v));
  if (!yyyy || !mm || !dd) return null;
  return new Date(yyyy, mm - 1, dd, 0, 0, 0, 0);
}

function parseCutoffMinutes(cutoffHour) {
  const [hh, mm] = String(cutoffHour || "18:00").split(":");
  const hours = Number(hh);
  const minutes = Number(mm);
  if (Number.isFinite(hours) && Number.isFinite(minutes)) {
    return hours * 60 + minutes;
  }
  return 18 * 60;
}

function calculateDaysLate(dueDateStr, cutoffHour) {
  const due = parseDueDateLocal(dueDateStr);
  if (!due) return 0;

  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
  const diffDays = Math.floor((today - due) / (1000 * 60 * 60 * 24));

  if (diffDays > 0) return diffDays;
  if (diffDays < 0) return 0;

  const cutoffMinutes = parseCutoffMinutes(cutoffHour);
  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  return nowMinutes >= cutoffMinutes ? 1 : 0;
}

function getSettings(callback) {
  db.get("SELECT * FROM settings WHERE id = 1", (err, row) => {
    if (err) {
      console.error("Erro ao buscar configurações:", err);
      callback(null);
    } else {
      callback(row);
    }
  });
}

export function setupInstallmentRoutes(app, authenticateToken) {
  app.get("/api/installments", authenticateToken, (req, res) => {
    getSettings((settings) => {
      if (!settings) {
        return res.status(500).json({ message: "Configurações não disponíveis" });
      }
      db.all(
        `
        SELECT i.*, l.client_id, c.name as client_name, c.document as client_document, c.phone as client_phone
        FROM installments i
        JOIN loans l ON i.loan_id = l.id
        JOIN clients c ON l.client_id = c.id
        ORDER BY i.due_date ASC
        `,
        [],
        (err, rows) => {
          if (err) {
            console.error("Erro ao buscar todas as parcelas:", err);
            return res.status(500).json({ message: "Erro ao buscar parcelas" });
          }
          const enriched = rows.map((inst) => {
            const daysLate =
              inst.status === "Pago" ? 0 : calculateDaysLate(inst.due_date, settings.cutoff_hour);
            return { ...inst, daysLate };
          });
          res.json(enriched);
        }
      );
    });
  });

  app.get("/api/loans/:loanId/installments", authenticateToken, (req, res) => {
    const loanId = Number(req.params.loanId);
    getSettings((settings) => {
      if (!settings) {
        return res.status(500).json({ message: "Configurações não disponíveis" });
      }
      db.all(
        `
        SELECT * FROM installments
        WHERE loan_id = ?
        ORDER BY due_date ASC
      `,
        [loanId],
        (err, rows) => {
          if (err) {
            console.error("Erro ao buscar parcelas:", err);
            return res.status(500).json({ message: "Erro ao buscar parcelas" });
          }
          const enriched = rows.map((inst) => {
            const daysLate =
              inst.status === "Pago" ? 0 : calculateDaysLate(inst.due_date, settings.cutoff_hour);
            return { ...inst, daysLate };
          });
          res.json(enriched);
        }
      );
    });
  });

  app.patch("/api/installments/:id/pay", authenticateToken, (req, res) => {
    const id = Number(req.params.id);
    const { amount, notes } = req.body;
    if (!amount || amount <= 0) {
      return res.status(400).json({ message: "Valor do pagamento inválido" });
    }
    db.get("SELECT * FROM installments WHERE id = ?", [id], (err, inst) => {
      if (err) {
        console.error("Erro ao buscar parcela:", err);
        return res.status(500).json({ message: "Erro ao buscar parcela" });
      }
      if (!inst) {
        return res.status(404).json({ message: "Parcela não encontrada" });
      }
      const before = { ...inst };
      const newPaidAmount = inst.paid_amount + amount;
      const totalDue = inst.original_amount + inst.interest_amount + inst.penalty_amount;
      const now = new Date().toISOString();
      getSettings((settings) => {
        const daysLate = settings ? calculateDaysLate(inst.due_date, settings.cutoff_hour) : 0;
        const newStatus = newPaidAmount >= totalDue ? "Pago" : "Em aberto";
        db.run(
          `
          UPDATE installments
          SET paid_amount = ?, status = ?, paid_at = ?, notes = COALESCE(?, notes), updated_at = ?
          WHERE id = ?
        `,
          [newPaidAmount, newStatus, now, notes || null, now, id],
          function (updateErr) {
            if (updateErr) {
              console.error("Erro ao registrar pagamento:", updateErr);
              return res.status(500).json({ message: "Erro ao registrar pagamento" });
            }
            addHistoryLog({
              userId: req.user.id,
              entityType: "installment",
              entityId: id,
              action: "pay",
              beforeData: before,
              afterData: { paid_amount: newPaidAmount, status: newStatus, notes, paid_at: now, daysLate },
              notes: null
            });
            res.json({ message: "Pagamento registrado", paid_amount: newPaidAmount, status: newStatus });
          }
        );
      });
    });
  });

  app.post("/api/loans/:loanId/installments", authenticateToken, (req, res) => {
    const loanId = Number(req.params.loanId);
    const { original_amount, due_date } = req.body;
    if (!original_amount || original_amount <= 0 || !due_date || !/^\d{4}-\d{2}-\d{2}$/.test(due_date)) {
      return res.status(400).json({ message: "Dados da nova parcela inválidos" });
    }
    db.get("SELECT * FROM loans WHERE id = ?", [loanId], (loanErr, loan) => {
      if (loanErr) {
        console.error("Erro ao buscar empréstimo:", loanErr);
        return res.status(500).json({ message: "Erro ao buscar empréstimo" });
      }
      if (!loan) {
        return res.status(404).json({ message: "Empréstimo não encontrado" });
      }
      db.get(
        "SELECT MAX(number) as maxNum FROM installments WHERE loan_id = ?",
        [loanId],
        (maxErr, row) => {
          if (maxErr) {
            console.error("Erro ao calcular número da parcela:", maxErr);
            return res.status(500).json({ message: "Erro ao calcular número da parcela" });
          }
          const nextNumber = (row && row.maxNum ? row.maxNum : 0) + 1;
          const now = new Date().toISOString();
          db.run(
            `
            INSERT INTO installments (
              loan_id, number, due_date, original_amount, interest_amount,
              penalty_amount, paid_amount, status, created_at, updated_at
            )
            VALUES (?, ?, ?, ?, 0, 0, 0, 'Em aberto', ?, ?)
          `,
            [loanId, nextNumber, due_date, original_amount, now, now],
            function (insertErr) {
              if (insertErr) {
                console.error("Erro ao adicionar parcela:", insertErr);
                return res.status(500).json({ message: "Erro ao adicionar parcela" });
              }
              const newInstallmentId = this.lastID;
              db.run(
                "UPDATE loans SET installments_count = ?, updated_at = ? WHERE id = ?",
                [nextNumber, now, loanId],
                function (updateLoanErr) {
                  if (updateLoanErr) {
                    console.error("Erro ao atualizar contagem de parcelas do empréstimo:", updateLoanErr);
                  }
                  addHistoryLog({
                    userId: req.user.id,
                    entityType: "installment",
                    entityId: newInstallmentId,
                    action: "create",
                    beforeData: null,
                    afterData: {
                      loan_id: loanId,
                      number: nextNumber,
                      due_date,
                      original_amount
                    },
                    notes: null
                  });
                  res.status(201).json({
                    id: newInstallmentId,
                    loan_id: loanId,
                    number: nextNumber,
                    due_date,
                    original_amount,
                    interest_amount: 0,
                    penalty_amount: 0,
                    paid_amount: 0,
                    status: "Em aberto"
                  });
                }
              );
            }
          );
        }
      );
    });
  });

  app.patch("/api/installments/:id", authenticateToken, (req, res) => {
    const id = Number(req.params.id);
    const { original_amount, interest_amount, penalty_amount, due_date, status, notes } = req.body;
    db.get("SELECT * FROM installments WHERE id = ?", [id], (err, inst) => {
      if (err) {
        console.error("Erro ao buscar parcela:", err);
        return res.status(500).json({ message: "Erro ao buscar parcela" });
      }
      if (!inst) {
        return res.status(404).json({ message: "Parcela não encontrada" });
      }
      const now = new Date().toISOString();
      db.run(
        `
        UPDATE installments
        SET original_amount = ?, interest_amount = ?, penalty_amount = ?,
            due_date = ?, status = ?, notes = ?, updated_at = ?
        WHERE id = ?
      `,
        [
          original_amount ?? inst.original_amount,
          interest_amount ?? inst.interest_amount,
          penalty_amount ?? inst.penalty_amount,
          due_date ?? inst.due_date,
          status ?? inst.status,
          notes ?? inst.notes,
          now,
          id
        ],
        function (updateErr) {
          if (updateErr) {
            console.error("Erro ao atualizar parcela:", updateErr);
            return res.status(500).json({ message: "Erro ao atualizar parcela" });
          }
          addHistoryLog({
            userId: req.user.id,
            entityType: "installment",
            entityId: id,
            action: "update",
            beforeData: inst,
            afterData: {
              original_amount,
              interest_amount,
              penalty_amount,
              due_date,
              status,
              notes
            },
            notes: null
          });
          res.json({ message: "Parcela atualizada" });
        }
      );
    });
  });

  app.post("/api/installments/:id/recalculate", authenticateToken, (req, res) => {
    const id = Number(req.params.id);
    db.get("SELECT * FROM installments WHERE id = ?", [id], (err, inst) => {
      if (err) {
        console.error("Erro ao buscar parcela:", err);
        return res.status(500).json({ message: "Erro ao buscar parcela" });
      }
      if (!inst) {
        return res.status(404).json({ message: "Parcela não encontrada" });
      }
      getSettings((settings) => {
        if (!settings) {
          return res.status(500).json({ message: "Configurações não disponíveis" });
        }
        const daysLate = calculateDaysLate(inst.due_date, settings.cutoff_hour);
        const interestAmount =
          daysLate > 0
            ? settings.interest_mode === "percent"
              ? inst.original_amount * (settings.daily_late_fee_percent / 100) * daysLate
              : settings.daily_late_fee_percent * daysLate
            : 0;
        const penaltyAmount = daysLate > 0 ? (Number(settings.fixed_late_fee) || 0) * daysLate : 0;
        const now = new Date().toISOString();
        db.run(
          `
          UPDATE installments
          SET interest_amount = ?, penalty_amount = ?, updated_at = ?
          WHERE id = ?
        `,
          [interestAmount, penaltyAmount, now, id],
          function (updateErr) {
            if (updateErr) {
              console.error("Erro ao recalcular parcela:", updateErr);
              return res.status(500).json({ message: "Erro ao recalcular parcela" });
            }
            addHistoryLog({
              userId: req.user.id,
              entityType: "installment",
              entityId: id,
              action: "recalculate",
              beforeData: inst,
              afterData: { interest_amount: interestAmount, penalty_amount: penaltyAmount },
              notes: null
            });
            res.json({ message: "Parcela recalculada", interest_amount: interestAmount, penalty_amount: penaltyAmount });
          }
        );
      });
    });
  });
}
