import { db } from "./db.js";
import { addHistoryLog } from "./history.js";

export function setupClientRoutes(app, authenticateToken) {
  app.get("/api/clients", authenticateToken, (req, res) => {
    db.all(
      `
      SELECT c.*, 
        (SELECT COUNT(*) FROM loans l WHERE l.client_id = c.id) as loans_count
      FROM clients c
      ORDER BY c.created_at DESC
    `,
      (err, rows) => {
        if (err) {
          console.error("Erro ao listar clientes:", err);
          return res.status(500).json({ message: "Erro ao listar clientes" });
        }
        res.json(rows);
      }
    );
  });

  app.post("/api/clients", authenticateToken, (req, res) => {
    const { name, document, phone, address, notes } = req.body;
    if (!name) {
      return res.status(400).json({ message: "Nome é obrigatório" });
    }
    const now = new Date().toISOString();
    db.run(
      `
      INSERT INTO clients (name, document, phone, address, notes, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `,
      [name, document || "", phone || "", address || "", notes || "", now, now],
      function (err) {
        if (err) {
          console.error("Erro ao criar cliente:", err);
          return res.status(500).json({ message: "Erro ao criar cliente" });
        }
        const id = this.lastID;
        addHistoryLog({
          userId: req.user.id,
          entityType: "client",
          entityId: id,
          action: "create",
          beforeData: null,
          afterData: { id, name, document, phone, address, notes },
          notes: null
        });
        res.status(201).json({ id, name, document, phone, address, notes, created_at: now, updated_at: now });
      }
    );
  });

  app.put("/api/clients/:id", authenticateToken, (req, res) => {
    const id = Number(req.params.id);
    const { name, document, phone, address, notes } = req.body;
    db.get("SELECT * FROM clients WHERE id = ?", [id], (err, client) => {
      if (err) {
        console.error("Erro ao buscar cliente:", err);
        return res.status(500).json({ message: "Erro ao buscar cliente" });
      }
      if (!client) {
        return res.status(404).json({ message: "Cliente não encontrado" });
      }
      const now = new Date().toISOString();
      db.run(
        `
        UPDATE clients
        SET name = ?, document = ?, phone = ?, address = ?, notes = ?, updated_at = ?
        WHERE id = ?
      `,
        [
          name ?? client.name,
          document ?? client.document,
          phone ?? client.phone,
          address ?? client.address,
          notes ?? client.notes,
          now,
          id
        ],
        function (updateErr) {
          if (updateErr) {
            console.error("Erro ao atualizar cliente:", updateErr);
            return res.status(500).json({ message: "Erro ao atualizar cliente" });
          }
          addHistoryLog({
            userId: req.user.id,
            entityType: "client",
            entityId: id,
            action: "update",
            beforeData: client,
            afterData: { id, name, document, phone, address, notes },
            notes: null
          });
          res.json({
            ...client,
            name: name ?? client.name,
            document: document ?? client.document,
            phone: phone ?? client.phone,
            address: address ?? client.address,
            notes: notes ?? client.notes,
            updated_at: now
          });
        }
      );
    });
  });

  app.delete("/api/clients/:id", authenticateToken, (req, res) => {
    if (!req.user || req.user.role !== "admin") {
      return res.status(403).json({ message: "Apenas administradores podem excluir clientes" });
    }
    const id = Number(req.params.id);
    db.get("SELECT * FROM clients WHERE id = ?", [id], (err, client) => {
      if (err) {
        console.error("Erro ao buscar cliente:", err);
        return res.status(500).json({ message: "Erro ao buscar cliente" });
      }
      if (!client) {
        return res.status(404).json({ message: "Cliente não encontrado" });
      }
      db.run("DELETE FROM clients WHERE id = ?", [id], function (deleteErr) {
        if (deleteErr) {
          console.error("Erro ao excluir cliente:", deleteErr);
          return res.status(500).json({ message: "Erro ao excluir cliente" });
        }
        addHistoryLog({
          userId: req.user.id,
          entityType: "client",
          entityId: id,
          action: "delete",
          beforeData: client,
          afterData: null,
          notes: null
        });
        res.status(204).end();
      });
    });
  });

  app.get("/api/clients/:id/loans", authenticateToken, (req, res) => {
    const id = Number(req.params.id);
    db.all(
      `
      SELECT * FROM loans
      WHERE client_id = ?
      ORDER BY created_at DESC
    `,
      [id],
      (err, rows) => {
        if (err) {
          console.error("Erro ao buscar empréstimos do cliente:", err);
          return res.status(500).json({ message: "Erro ao buscar empréstimos" });
        }
        res.json(rows);
      }
    );
  });

  app.get("/api/clients/:id/outstanding", authenticateToken, (req, res) => {
    const id = Number(req.params.id);
    db.get(
      `
      SELECT COALESCE(
        SUM( MAX( (i.original_amount + i.interest_amount + i.penalty_amount) - i.paid_amount, 0) ),
        0
      ) AS outstanding
      FROM installments i
      JOIN loans l ON l.id = i.loan_id
      WHERE l.client_id = ? AND i.status != 'Pago'
    `,
      [id],
      (err, row) => {
        if (err) {
          console.error("Erro ao calcular total em aberto do cliente:", err);
          return res.status(500).json({ message: "Erro ao calcular total em aberto" });
        }
        res.json({ outstanding: Number(row?.outstanding || 0) });
      }
    );
  });
}
