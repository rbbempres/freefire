import { db } from "./db.js";

function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) return reject(err);
      resolve(row);
    });
  });
}

function dbAll(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) return reject(err);
      resolve(rows || []);
    });
  });
}

function parseDueDateLocal(dueDateStr) {
  if (!dueDateStr) return null;
  const [yyyy, mm, dd] = String(dueDateStr).split("-").map((v) => Number(v));
  if (!yyyy || !mm || !dd) return null;
  return new Date(yyyy, mm - 1, dd, 0, 0, 0, 0);
}

function parseCutoffMinutes(cutoffHour) {
  const [hh, mm] = String(cutoffHour || "18:00").split(":");
  const hours = Number(hh);
  const minutes = Number(mm);
  if (Number.isFinite(hours) && Number.isFinite(minutes)) {
    return hours * 60 + minutes;
  }
  return 18 * 60;
}

function calculateDaysLate(dueDateStr, cutoffHour) {
  const due = parseDueDateLocal(dueDateStr);
  if (!due) return 0;

  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
  const diffDays = Math.floor((today - due) / (1000 * 60 * 60 * 24));

  if (diffDays > 0) return diffDays;
  if (diffDays < 0) return 0;

  const cutoffMinutes = parseCutoffMinutes(cutoffHour);
  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  return nowMinutes >= cutoffMinutes ? 1 : 0;
}

export function setupDashboardRoutes(app, authenticateToken) {
  app.get("/api/dashboard", authenticateToken, async (req, res) => {
    try {
      const days = Number(req.query.days ?? req.query.period);
      const rangeDays = Number.isFinite(days) && days > 0 ? Math.floor(days) : null;

      const now = new Date();
      const todayDate = now.toISOString().slice(0, 10);
      const startDateTime = rangeDays ? new Date(now.getTime() - rangeDays * 24 * 60 * 60 * 1000) : null;
      const startISO = startDateTime ? startDateTime.toISOString() : null;
      const startDate = startISO ? startISO.slice(0, 10) : null;

      const settings = await dbGet("SELECT * FROM settings WHERE id = 1");
      const cutoffHour = settings?.cutoff_hour || "18:00";
      const fixedLateFee = Number(settings?.fixed_late_fee) || 0;
      const interestMode = settings?.interest_mode || "percent";
      const dailyLateFee = Number(settings?.daily_late_fee_percent) || 0;

      const loanWhere = startISO ? "WHERE created_at >= ?" : "";
      const loanParams = startISO ? [startISO] : [];
      const loanRow = await dbGet(
        `SELECT COALESCE(SUM(principal), 0) as total, COUNT(*) as count FROM loans ${loanWhere}`,
        loanParams
      );

      const payWhere = startISO ? "AND created_at >= ?" : "";
      const payParams = startISO ? [startISO] : [];
      const payRows = await dbAll(
        `
        SELECT before_data, after_data
        FROM history_logs
        WHERE entity_type = 'installment' AND action = 'pay'
        ${payWhere}
      `,
        payParams
      );
      const totalRecebido = payRows.reduce((sum, r) => {
        try {
          const before = JSON.parse(r.before_data || "{}");
          const after = JSON.parse(r.after_data || "{}");
          const beforePaid = Number(before.paid_amount) || 0;
          const afterPaid = Number(after.paid_amount) || 0;
          const delta = afterPaid - beforePaid;
          return sum + (delta > 0 ? delta : 0);
        } catch {
          return sum;
        }
      }, 0);

      const installmentParams = [];
      let installmentWhere = "WHERE i.status != 'Pago' AND i.due_date <= ?";
      installmentParams.push(todayDate);
      if (startDate) {
        installmentWhere += " AND i.due_date >= ?";
        installmentParams.push(startDate);
      }

      const openInstallments = await dbAll(
        `
        SELECT i.*, l.client_id
        FROM installments i
        JOIN loans l ON l.id = i.loan_id
        ${installmentWhere}
      `,
        installmentParams
      );

      let totalEmAtraso = 0;
      let totalMultas = 0;
      let totalJurosAtraso = 0;
      let parcelasAtrasadas = 0;
      const clientSet = new Set();

      for (const inst of openInstallments) {
        const daysLate = calculateDaysLate(inst.due_date, cutoffHour);
        if (daysLate <= 0) continue;

        const interestAmount =
          interestMode === "percent"
            ? inst.original_amount * (dailyLateFee / 100) * daysLate
            : dailyLateFee * daysLate;
        const penaltyAmount = fixedLateFee * daysLate;
        const totalDue = inst.original_amount + interestAmount + penaltyAmount;
        const outstanding = Math.max(totalDue - inst.paid_amount, 0);

        if (outstanding > 0) {
          totalEmAtraso += outstanding;
          totalMultas += penaltyAmount;
          totalJurosAtraso += interestAmount;
          parcelasAtrasadas += 1;
          clientSet.add(inst.client_id);
        }
      }

      const dueTodayRow = await dbGet(
        `SELECT COUNT(*) as count FROM installments WHERE status != 'Pago' AND due_date = ?`,
        [todayDate]
      );

      res.json({
        rangeDays,
        startDate,
        totalEmprestado: Number(loanRow?.total) || 0,
        emprestimosNoPeriodo: Number(loanRow?.count) || 0,
        totalRecebido,
        pagamentosNoPeriodo: payRows.length,
        totalEmAtraso,
        totalMultas,
        totalJurosAtraso,
        parcelasAtrasadas,
        parcelasVencemHoje: Number(dueTodayRow?.count) || 0,
        clientesInadimplentes: clientSet.size,
        multaDiaria: fixedLateFee
      });
    } catch (err) {
      console.error("Erro no dashboard:", err);
      res.status(500).json({ message: "Erro ao buscar dashboard" });
    }
  });
}
