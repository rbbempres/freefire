import sqlite3 from "sqlite3";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import bcrypt from "bcryptjs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataDir = path.join(__dirname, "..", "data");

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, "database.sqlite");

sqlite3.verbose();

export const db = new sqlite3.Database(dbPath);

export function initDatabase() {
  db.serialize(() => {
    db.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK (role IN ('admin', 'operator')),
        plan_days INTEGER NOT NULL DEFAULT 30,
        created_at TEXT NOT NULL
      )
    `);

    db.all("PRAGMA table_info(users)", (err, rows) => {
      if (err) {
        console.error("Erro ao verificar colunas de usuários:", err);
      } else {
        const hasPlanDays = Array.isArray(rows) && rows.some((c) => c.name === "plan_days");
        if (!hasPlanDays) {
          db.run("ALTER TABLE users ADD COLUMN plan_days INTEGER NOT NULL DEFAULT 30");
        }
      }
    });

    db.run(`
      CREATE TABLE IF NOT EXISTS clients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        document TEXT,
        phone TEXT,
        address TEXT,
        notes TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS loans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_id INTEGER NOT NULL,
        principal REAL NOT NULL,
        interest_type TEXT NOT NULL,
        interest_rate REAL NOT NULL,
        installments_count INTEGER NOT NULL,
        installment_value REAL NOT NULL,
        start_date TEXT NOT NULL,
        status TEXT NOT NULL,
        config_json TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (client_id) REFERENCES clients (id)
      )
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS installments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        loan_id INTEGER NOT NULL,
        number INTEGER NOT NULL,
        due_date TEXT NOT NULL,
        original_amount REAL NOT NULL,
        interest_amount REAL NOT NULL DEFAULT 0,
        penalty_amount REAL NOT NULL DEFAULT 0,
        paid_amount REAL NOT NULL DEFAULT 0,
        status TEXT NOT NULL,
        paid_at TEXT,
        notes TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (loan_id) REFERENCES loans (id)
      )
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS settings (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        interest_mode TEXT NOT NULL DEFAULT 'percent',
        daily_late_fee_percent REAL NOT NULL DEFAULT 0,
        fixed_late_fee REAL NOT NULL DEFAULT 0,
        cutoff_hour TEXT NOT NULL DEFAULT '18:00'
      )
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS history_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        entity_type TEXT NOT NULL,
        entity_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        before_data TEXT,
        after_data TEXT,
        notes TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users (id)
      )
    `);

    db.get("SELECT COUNT(*) AS count FROM users", (err, row) => {
      if (err) {
        console.error("Erro ao verificar usuários iniciais:", err);
        return;
      }
      if (row.count === 0) {
        const passwordHash = bcrypt.hashSync("admin123", 10);
        const now = new Date().toISOString();
        db.run(
          `
          INSERT INTO users (name, email, password_hash, role, plan_days, created_at)
          VALUES (?, ?, ?, ?, ?, ?)
        `,
          ["Administrador", "admin@sistema.com", passwordHash, "admin", 30, now]
        );
      }
      db.get("SELECT COUNT(*) AS count FROM users WHERE email = ?", ["operador@sistema.com"], (err2, row2) => {
        if (err2) {
          console.error("Erro ao verificar usuário operador:", err2);
          return;
        }
        if (!row2 || row2.count === 0) {
          const opHash = bcrypt.hashSync("operador123", 10);
          const now = new Date().toISOString();
          db.run(
            `
            INSERT INTO users (name, email, password_hash, role, plan_days, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
          `,
            ["Operador", "operador@sistema.com", opHash, "operator", 30, now]
          );
        }
      });
    });

    db.get("SELECT COUNT(*) AS count FROM settings", (err, row) => {
      if (err) {
        console.error("Erro ao verificar configurações iniciais:", err);
        return;
      }
      if (row.count === 0) {
        db.run(
          `
          INSERT INTO settings (id, interest_mode, daily_late_fee_percent, fixed_late_fee, cutoff_hour)
          VALUES (1, 'percent', 1.0, 0, '18:00')
        `
        );
      }
    });
  });
}
