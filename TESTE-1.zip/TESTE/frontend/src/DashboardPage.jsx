import React, { useEffect, useState } from "react";
import { useAuth } from "./AuthContext.jsx";

export default function DashboardPage() {
  const { apiFetch } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [days, setDays] = useState("30");

  useEffect(() => {
    async function load() {
      setLoading(true);
      setError("");
      try {
        const params = days ? `?days=${encodeURIComponent(days)}` : "";
        const res = await apiFetch(`/api/dashboard${params}`);
        setData(res);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [apiFetch, days]);

  if (loading) return <div>Carregando resumo...</div>;
  if (error) return <div>Erro: {error}</div>;
  if (!data) return null;

  const titleSuffix = data.rangeDays ? ` (últimos ${data.rangeDays} dias)` : "";

  return (
    <>
      <div className="pill-filters" style={{ marginBottom: "0.75rem" }}>
        {[
          { label: "Total", value: "" },
          { label: "7 dias", value: "7" },
          { label: "15 dias", value: "15" },
          { label: "30 dias", value: "30" },
          { label: "90 dias", value: "90" }
        ].map((opt) => (
          <button
            key={opt.value || "total"}
            className={`pill ${days === opt.value ? "active" : ""}`}
            onClick={() => setDays(opt.value)}
          >
            {opt.label}
          </button>
        ))}
      </div>
      <div className="card-grid">
        <div className="card">
          <div className="card-title">Emprestado{titleSuffix}</div>
          <div className="card-value">R$ {Number(data.totalEmprestado || 0).toFixed(2)}</div>
          <div className="card-subtitle">{Number(data.emprestimosNoPeriodo || 0)} empréstimos</div>
        </div>
        <div className="card">
          <div className="card-title">Recebido{titleSuffix}</div>
          <div className="card-value">R$ {Number(data.totalRecebido || 0).toFixed(2)}</div>
          <div className="card-subtitle">{Number(data.pagamentosNoPeriodo || 0)} pagamentos</div>
        </div>
        <div className="card">
          <div className="card-title">Em atraso (com juros + multa)</div>
          <div className="card-value" style={{ color: "#b91c1c" }}>
            R$ {Number(data.totalEmAtraso || 0).toFixed(2)}
          </div>
          <div className="card-subtitle">{Number(data.parcelasAtrasadas || 0)} parcelas atrasadas</div>
        </div>
        <div className="card">
          <div className="card-title">Juros do atraso (calculado)</div>
          <div className="card-value">R$ {Number(data.totalJurosAtraso || 0).toFixed(2)}</div>
        </div>
        <div className="card">
          <div className="card-title">Multas do atraso (calculado)</div>
          <div className="card-value">R$ {Number(data.totalMultas || 0).toFixed(2)}</div>
          <div className="card-subtitle">Multa diária: R$ {Number(data.multaDiaria || 0).toFixed(2)}</div>
        </div>
        <div className="card">
          <div className="card-title">Parcelas vencem hoje</div>
          <div className="card-value">{Number(data.parcelasVencemHoje || 0)}</div>
        </div>
        <div className="card">
          <div className="card-title">Clientes inadimplentes</div>
          <div className="card-value">{Number(data.clientesInadimplentes || 0)}</div>
        </div>
      </div>
    </>
  );
}
