import React, { useEffect, useState } from "react";
import { useAuth } from "./AuthContext.jsx";

export default function SettingsPage() {
  const { apiFetch, user } = useAuth();
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [importing, setImporting] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await apiFetch("/api/settings");
      setSettings(res);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function handleSave(e) {
    e.preventDefault();
    if (user.role !== "admin") {
      alert("Apenas administradores podem alterar as regras de juros.");
      return;
    }
    try {
      await apiFetch("/api/settings", {
        method: "PUT",
        body: JSON.stringify(settings)
      });
      alert("Configurações salvas.");
    } catch (err) {
      alert(err.message);
    }
  }

  if (loading) return <div>Carregando...</div>;
  if (error) return <div>Erro: {error}</div>;
  if (!settings) return null;

  async function handleExport() {
    try {
      const backup = await apiFetch("/api/settings/backup/export");
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      const dateStr = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
      a.download = `backup-gestor-${dateStr}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      alert(err.message);
    }
  }

  async function handleImportFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setImporting(true);
    try {
      const text = await file.text();
      const json = JSON.parse(text);
      await apiFetch("/api/settings/backup/import", {
        method: "POST",
        body: JSON.stringify(json)
      });
      alert("Backup importado com sucesso.");
      await load();
    } catch (err) {
      alert(err.message);
    } finally {
      setImporting(false);
      e.target.value = "";
    }
  }

  return (
    <div className="layout-main">
      <div className="panel">
        <div className="panel-header">
          <div className="panel-title">Configurações de juros e multas</div>
        </div>
        <form onSubmit={handleSave}>
          <div className="form-row">
            <div className="form-group">
              <label>Modo de juros de atraso</label>
              <select
                value={settings.interest_mode}
                onChange={(e) => setSettings({ ...settings, interest_mode: e.target.value })}
              >
                <option value="percent">Percentual diário</option>
                <option value="fixed">Valor fixo diário</option>
              </select>
            </div>
            <div className="form-group">
              <label>
                Valor / % ao dia ({settings.interest_mode === "percent" ? "%" : "R$"})
              </label>
              <input
                type="number"
                step="0.01"
                value={settings.daily_late_fee_percent}
                onChange={(e) =>
                  setSettings({ ...settings, daily_late_fee_percent: Number(e.target.value) })
                }
              />
            </div>
            <div className="form-group">
              <label>Multa fixa (após horário limite)</label>
              <input
                type="number"
                step="0.01"
                value={settings.fixed_late_fee}
                onChange={(e) => setSettings({ ...settings, fixed_late_fee: Number(e.target.value) })}
              />
            </div>
            <div className="form-group">
              <label>Horário limite</label>
              <input
                type="time"
                value={settings.cutoff_hour}
                onChange={(e) => setSettings({ ...settings, cutoff_hour: e.target.value })}
              />
            </div>
          </div>
          <div className="form-actions">
            <button className="btn btn-primary" type="submit">
              Salvar configurações
            </button>
          </div>
        </form>
      </div>
      <div className="panel">
        <div className="panel-header">
          <div className="panel-title">Backup</div>
          <div className="panel-subtitle">Exporte e importe seus dados</div>
        </div>
        <div className="form-actions">
          <button className="btn btn-secondary" onClick={handleExport}>Exportar backup (JSON)</button>
          <label className="btn btn-primary" style={{ cursor: "pointer" }}>
            {importing ? "Importando..." : "Importar backup (JSON)"}
            <input type="file" accept=".json,application/json" onChange={handleImportFile} style={{ display: "none" }} />
          </label>
        </div>
        <div className="card-subtitle">
          Inclui: usuários, clientes, empréstimos, parcelas e configurações.
        </div>
      </div>
    </div>
  );
}
