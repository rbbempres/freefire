import React, { useEffect, useState } from "react";
import { useAuth } from "./AuthContext.jsx";

export default function LoanDetailsPage({ loanId, onBack }) {
  const { apiFetch } = useAuth();
  const [loan, setLoan] = useState(null);
  const [installments, setInstallments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [newInstAmount, setNewInstAmount] = useState("");
  const [newInstDate, setNewInstDate] = useState("");
  const [payModal, setPayModal] = useState({ visible: false, inst: null, amount: "", notes: "" });

  async function load() {
    if (!loanId) return;
    setLoading(true);
    setError("");
    try {
      const res = await apiFetch(`/api/loans/${loanId}`);
      setLoan(res.loan);
      setInstallments(res.installments);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [loanId]);

  function updateInstallmentDueDate(id, value) {
    setInstallments((prev) => prev.map((inst) => (inst.id === id ? { ...inst, due_date: value } : inst)));
  }

  async function saveInstallmentDate(inst) {
    try {
      await apiFetch(`/api/installments/${inst.id}`, {
        method: "PATCH",
        body: JSON.stringify({ due_date: inst.due_date })
      });
      await load();
    } catch (err) {
      alert(err.message);
    }
  }

  async function markInstallmentPaid(inst) {
    const total = inst.original_amount + inst.interest_amount + inst.penalty_amount;
    const remaining = Math.max(0, total - (inst.paid_amount || 0));
    setPayModal({ visible: true, inst, amount: remaining.toFixed(2), notes: "" });
  }

  async function recalcInstallment(inst) {
    try {
      await apiFetch(`/api/installments/${inst.id}/recalculate`, {
        method: "POST"
      });
      await load();
    } catch (err) {
      alert(err.message);
    }
  }

  async function addExtraInstallment() {
    const amount = Number(String(newInstAmount).replace(",", "."));
    const date = newInstDate;
    if (!amount || amount <= 0 || !date) {
      alert("Informe valor e data da nova parcela");
      return;
    }
    try {
      await apiFetch(`/api/loans/${loanId}/installments`, {
        method: "POST",
        body: JSON.stringify({ original_amount: amount, due_date: date })
      });
      setNewInstAmount("");
      setNewInstDate("");
      await load();
    } catch (err) {
      alert(err.message);
    }
  }

  if (!loanId) return <div className="panel">Selecione um empréstimo.</div>;

  return (
    <div className="panel">
      <div className="panel-header">
        <div className="panel-title">
          {loan ? `Empréstimo #${loan.id} - ${loan.client_name}` : "Carregando..."}
        </div>
        <div>
          <button className="btn btn-secondary" onClick={onBack}>
            Voltar
          </button>
        </div>
      </div>
      {loading && <div>Carregando...</div>}
      {error && <div>Erro: {error}</div>}
      {!loading && loan && (
        <>
          <div className="card" style={{ marginTop: "0.5rem" }}>
            <div className="form-row">
              <div className="form-group">
                <label>Valor emprestado</label>
                <div>R$ {loan.principal.toFixed(2)}</div>
              </div>
              <div className="form-group">
                <label>Parcelas</label>
                <div>{loan.installments_count} x</div>
              </div>
              <div className="form-group">
                <label>Juros</label>
                <div>
                  {loan.interest_rate}% {loan.interest_type}
                </div>
              </div>
              <div className="form-group">
                <label>Status</label>
                <div>{loan.status}</div>
              </div>
            </div>
          </div>
          <div className="card" style={{ marginTop: "0.5rem" }}>
            <div className="form-row">
              <div className="form-group">
                <label>Nova parcela - Valor</label>
                <input
                  type="number"
                  step="0.01"
                  placeholder="Ex: 100.00"
                  value={newInstAmount}
                  onChange={(e) => setNewInstAmount(e.target.value)}
                />
              </div>
              <div className="form-group">
                <label>Nova parcela - Vencimento</label>
                <input
                  type="date"
                  value={newInstDate}
                  onChange={(e) => setNewInstDate(e.target.value)}
                />
              </div>
              <div className="form-group" style={{ alignSelf: "flex-end" }}>
                <button className="btn btn-primary" onClick={addExtraInstallment}>
                  Adicionar parcela
                </button>
              </div>
            </div>
          </div>
          <div style={{ overflowX: "auto" }}>
            <table className="table" style={{ marginTop: "0.5rem" }}>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Vencimento</th>
                  <th>Valor</th>
                  <th>Juros</th>
                  <th>Multa</th>
                  <th>Pago</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {installments.map((inst) => (
                  <tr key={inst.id}>
                    <td className="td-right">{inst.number}</td>
                    <td>
                      <input
                        type="date"
                        value={inst.due_date}
                        onChange={(e) => updateInstallmentDueDate(inst.id, e.target.value)}
                      />
                    </td>
                    <td className="td-right">R$ {inst.original_amount.toFixed(2)}</td>
                    <td className="td-right">R$ {inst.interest_amount.toFixed(2)}</td>
                    <td className="td-right">R$ {inst.penalty_amount.toFixed(2)}</td>
                    <td className="td-right">R$ {inst.paid_amount.toFixed(2)}</td>
                    <td>{inst.status}</td>
                    <td className="td-actions">
                      <button className="btn btn-sm btn-primary" onClick={() => markInstallmentPaid(inst)}>
                        Registrar pagamento
                      </button>{" "}
                      <button className="btn btn-sm btn-secondary" onClick={() => recalcInstallment(inst)}>
                        Recalcular
                      </button>{" "}
                      <button className="btn btn-sm btn-secondary" onClick={() => saveInstallmentDate(inst)}>
                        Salvar data
                      </button>
                    </td>
                  </tr>
                ))}
              {installments.length === 0 && (
                <tr>
                  <td colSpan={8}>Nenhuma parcela cadastrada.</td>
                </tr>
              )}
              </tbody>
            </table>
          </div>
          {payModal.visible && (
            <div
              style={{
                position: "fixed",
                inset: 0,
                background: "rgba(0,0,0,0.4)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                zIndex: 9999
              }}
            >
              <div className="panel" style={{ maxWidth: 420, width: "90%" }}>
                <div className="panel-header">
                  <div className="panel-title">Registrar pagamento</div>
                  <div className="panel-subtitle">
                    {payModal.inst ? `#${payModal.inst.number}` : ""}
                  </div>
                </div>
                <div className="form-group">
                  <label>Valor pago</label>
                  <input
                    type="number"
                    step="0.01"
                    value={payModal.amount}
                    onChange={(e) => setPayModal({ ...payModal, amount: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>Observação (opcional)</label>
                  <textarea
                    rows={3}
                    value={payModal.notes}
                    onChange={(e) => setPayModal({ ...payModal, notes: e.target.value })}
                  />
                </div>
                <div className="form-actions">
                  <button
                    className="btn btn-primary"
                    onClick={async () => {
                      const inst = payModal.inst;
                      const amount = Number(String(payModal.amount).replace(",", "."));
                      if (!inst || !amount || amount <= 0) {
                        alert("Informe um valor válido.");
                        return;
                      }
                      try {
                        await apiFetch(`/api/installments/${inst.id}/pay`, {
                          method: "PATCH",
                          body: JSON.stringify({ amount, notes: payModal.notes || undefined })
                        });
                        setPayModal({ visible: false, inst: null, amount: "", notes: "" });
                        await load();
                      } catch (err) {
                        alert(err.message);
                      }
                    }}
                  >
                    Confirmar
                  </button>
                  <button
                    className="btn btn-secondary"
                    onClick={() => setPayModal({ visible: false, inst: null, amount: "", notes: "" })}
                  >
                    Cancelar
                  </button>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
