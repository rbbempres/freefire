import React, { useState } from "react";
import { useAuth } from "./AuthContext.jsx";

export default function LoginPage() {
  const { saveAuth } = useAuth();
  const [email, setEmail] = useState("admin@sistema.com");
  const [password, setPassword] = useState("admin123");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.message || "Falha no login");
      }
      const data = await res.json();
      saveAuth(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-container">
      <div className="login-box">
        <div className="login-brand">RBB</div>
        <div className="login-title">Gestor de Empréstimos</div>
        <div className="login-subtitle">Acesse com seu usuário</div>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Email</label>
            <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" required />
          </div>
          <div className="form-group" style={{ marginTop: "0.75rem" }}>
            <label>Senha</label>
            <input
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              type="password"
              required
            />
          </div>
          {error && (
            <div style={{ color: "#b91c1c", fontSize: "0.8rem", marginTop: "0.5rem" }}>{error}</div>
          )}
          <button className="btn btn-primary" style={{ width: "100%", marginTop: "1rem" }} disabled={loading}>
            {loading ? "Entrando..." : "Entrar"}
          </button>
        </form>
        <div className="login-footer">
          Usuários iniciais:
          <div>
            Admin: <strong>admin@sistema.com</strong> / <strong>admin123</strong>
          </div>
          <div>
            Operador: <strong>operador@sistema.com</strong> / <strong>operador123</strong>
          </div>
        </div>
      </div>
    </div>
  );
}
