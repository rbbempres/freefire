import React, { useEffect, useState } from "react";
import { useAuth } from "./AuthContext.jsx";

function StatusTag({ value }) {
  return <span className={`status-tag status-${value}`}>{value}</span>;
}

function normalizePhone(phone) {
  const digits = String(phone || "").replace(/\D/g, "");
  if (!digits) return "";
  if (digits.startsWith("55")) return digits;
  if (digits.length === 10 || digits.length === 11) return `55${digits}`;
  return digits;
}

function formatDateBr(dateStr) {
  if (!dateStr) return "";
  const [yyyy, mm, dd] = dateStr.split("-");
  if (!yyyy || !mm || !dd) return dateStr;
  return `${dd}/${mm}/${yyyy}`;
}

function formatCurrencyBr(value) {
  const number = Number(value) || 0;
  return number.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function encodeForWhatsApp(text) {
  if (typeof TextEncoder !== "undefined") {
    const bytes = new TextEncoder().encode(String(text));
    let out = "";
    for (const b of bytes) out += `%${b.toString(16).padStart(2, "0").toUpperCase()}`;
    return out;
  }
  return encodeURIComponent(text);
}

export default function BillingPage() {
  const { apiFetch } = useAuth();
  const [installments, setInstallments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filterStatus, setFilterStatus] = useState("Em aberto");
  const [payModal, setPayModal] = useState({ visible: false, inst: null, amount: "", notes: "" });

  async function load() {
    setLoading(true);
    try {
      const res = await apiFetch("/api/installments");
      setInstallments(res);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function markPaid(inst) {
    const valueStr = window.prompt(
      `Informe o valor pago na parcela #${inst.number} de ${inst.client_name}`,
      (inst.original_amount + inst.interest_amount + inst.penalty_amount - inst.paid_amount).toFixed(2)
    );
    if (!valueStr) return;
    const amount = Number(valueStr.replace(",", "."));
    if (!amount || amount <= 0) return;

    try {
      await apiFetch(`/api/installments/${inst.id}/pay`, {
        method: "PATCH",
        body: JSON.stringify({ amount })
      });
      await load();
    } catch (err) {
      alert(err.message);
    }
  }

  const filtered = filterStatus
    ? installments.filter((i) => {
        if (filterStatus === "Atrasado") {
          return i.status !== "Pago" && Number(i.daysLate || 0) > 0;
        }
        return i.status === filterStatus;
      })
    : installments;

  function openPay(inst) {
    const totalDue = inst.original_amount + inst.interest_amount + inst.penalty_amount;
    const remaining = Math.max(0, totalDue - (inst.paid_amount || 0));
    setPayModal({ visible: true, inst, amount: remaining.toFixed(2), notes: "" });
  }

  function closePay() {
    setPayModal({ visible: false, inst: null, amount: "", notes: "" });
  }

  async function confirmPay() {
    const inst = payModal.inst;
    const amount = Number(String(payModal.amount).replace(",", "."));
    if (!inst || !amount || amount <= 0) {
      alert("Informe um valor válido.");
      return;
    }
    try {
      await apiFetch(`/api/installments/${inst.id}/pay`, {
        method: "PATCH",
        body: JSON.stringify({ amount, notes: payModal.notes || undefined })
      });
      closePay();
      await load();
    } catch (err) {
      alert(err.message);
    }
  }

  function openWhatsApp(inst) {
    const phone = normalizePhone(inst.client_phone);
    if (!phone) {
      alert("Cliente sem telefone cadastrado.");
      return;
    }
    const totalDue = inst.original_amount + inst.interest_amount + inst.penalty_amount;
    const dueDateBr = formatDateBr(inst.due_date);
    const daysLate = Number(inst.daysLate) || 0;
    const originalBr = formatCurrencyBr(inst.original_amount);
    const multasBr = formatCurrencyBr(inst.interest_amount + inst.penalty_amount);
    const totalBr = formatCurrencyBr(totalDue);
    const message = `${inst.client_name}, este é um aviso de cobrança.\n\nParcela #${inst.number} com vencimento em ${dueDateBr}.\nValor da parcela: R$ ${originalBr}\nMultas/Juros: R$ ${multasBr}\nTotal: R$ ${totalBr}\n\nEncontra-se em atraso há ${daysLate} dias.\n\nPagamento somente para esse pix\n\nChave Pix: 39998848865.\n\nNome : Thaunne Souza Moraes.\n\nBanco : Santander\n\nAguardo a confirmação do comprovante o quanto antes. Passou das 18:00 multa de 50$ diaria`;
    const url = `https://wa.me/${phone}?text=${encodeForWhatsApp(message)}`;
    window.open(url, "_blank", "noopener,noreferrer");
  }

  return (
    <div className="layout-main" style={{ display: "block", gridTemplateColumns: "1fr" }}>
      <div>
        <h2 style={{ marginBottom: "0.5rem" }}>Cobrança - Todas as Parcelas</h2>
        <div className="pill-filters" style={{ marginBottom: "0.5rem" }}>
          {["Em aberto", "", "Pago", "Atrasado"].map((st) => (
            <button
              key={st || "todos"}
              className={`pill ${filterStatus === st ? "active" : ""}`}
              onClick={() => setFilterStatus(st)}
            >
              {st || "Todas"}
            </button>
          ))}
        </div>
        
        {loading && <div>Carregando...</div>}
        {error && <div>Erro: {error}</div>}

        <div style={{ overflowX: "auto" }}>
          <table className="table">
            <thead>
              <tr>
                <th>Vencimento</th>
                <th>Cliente</th>
                <th>Parcela</th>
                <th>Valor Original</th>
                <th>Juros/Multa</th>
                <th>Total Devido</th>
                <th>Pago</th>
                <th>Status</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((inst) => {
                const totalDue = inst.original_amount + inst.interest_amount + inst.penalty_amount;
                const isLate = inst.daysLate > 0;
                const rowStyle = isLate && inst.status !== "Pago" ? { backgroundColor: "#fff1f2" } : {};

                return (
                  <tr key={inst.id} style={rowStyle}>
                    <td>{formatDateBr(inst.due_date)}</td>
                    <td>{inst.client_name}</td>
                    <td>{inst.number}</td>
                    <td>R$ {inst.original_amount.toFixed(2)}</td>
                    <td>R$ {(inst.interest_amount + inst.penalty_amount).toFixed(2)}</td>
                    <td>R$ {totalDue.toFixed(2)}</td>
                    <td>R$ {inst.paid_amount.toFixed(2)}</td>
                    <td>
                      <StatusTag value={inst.status} />
                      {isLate && inst.status !== "Pago" && (
                        <div style={{ fontSize: "0.7rem", color: "red" }}>
                          {inst.daysLate} dias atraso
                        </div>
                      )}
                    </td>
                    <td>
                      {inst.status !== "Pago" && (
                        <>
                          <button
                            className="btn btn-sm btn-primary"
                            onClick={() => openPay(inst)}
                          >
                            Receber
                          </button>{" "}
                          <button
                            className="btn btn-sm btn-secondary"
                            onClick={() => openWhatsApp(inst)}
                          >
                            WhatsApp
                          </button>
                        </>
                      )}
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && !loading && (
                <tr>
                  <td colSpan={9}>Nenhuma parcela encontrada.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      {payModal.visible && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.4)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 9999
          }}
        >
          <div className="panel" style={{ maxWidth: 420, width: "90%" }}>
            <div className="panel-header">
              <div className="panel-title">Registrar pagamento</div>
              <div className="panel-subtitle">
                {payModal.inst
                  ? `#${payModal.inst.number} • ${payModal.inst.client_name}`
                  : ""}
              </div>
            </div>
            <div className="form-group">
              <label>Valor pago</label>
              <input
                type="number"
                step="0.01"
                value={payModal.amount}
                onChange={(e) => setPayModal({ ...payModal, amount: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label>Observação (opcional)</label>
              <textarea
                rows={3}
                value={payModal.notes}
                onChange={(e) => setPayModal({ ...payModal, notes: e.target.value })}
              />
            </div>
            <div className="form-actions">
              <button className="btn btn-primary" onClick={confirmPay}>
                Confirmar
              </button>
              <button className="btn btn-secondary" onClick={closePay}>
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
