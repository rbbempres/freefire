import React, { useEffect, useState } from "react";
import { useAuth } from "./AuthContext.jsx";

function StatusTag({ value }) {
  return <span className={`status-tag status-${value}`}>{value}</span>;
}

export default function LoansPage({ onOpenLoan }) {
  const { apiFetch } = useAuth();
  const [loans, setLoans] = useState([]);
  const [plannedDates, setPlannedDates] = useState([]);
  const [manualDates, setManualDates] = useState(false);
  const [filterStatus, setFilterStatus] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [form, setForm] = useState({
    client_id: "",
    principal: "",
    interest_type: "mensal",
    interest_rate: 30,
    installments_count: 6,
    installment_value: "",
    start_date: new Date().toISOString().slice(0, 10),
    status: "Ativo"
  });

  const principalNumber = Number(form.principal) || 0;
  const installmentsCountNumber = Number(form.installments_count) || 0;
  const interestRateNumber = Number(form.interest_rate) || 0;
  const interestType = form.interest_type;

  function getInterestFactorByType(type) {
    if (type === "diario") return 1 / 29;
    if (type === "semanal") return 7 / 29;
    if (type === "quinzenal") return 0.5;
    return 1;
  }

  function getDaysByType(type) {
    if (type === "diario") return 1;
    if (type === "semanal") return 7;
    if (type === "quinzenal") return 15;
    return 29;
  }

  const interestFactor = getInterestFactorByType(interestType);
  const effectiveRatePerInstallment = interestRateNumber * interestFactor;
  const totalInterest =
    principalNumber * (effectiveRatePerInstallment / 100) * installmentsCountNumber;
  const totalWithInterest = principalNumber + totalInterest;
  const autoInstallmentValue =
    installmentsCountNumber > 0 ? totalWithInterest / installmentsCountNumber : 0;

  function generateDatesPreview() {
    if (!form.start_date || !installmentsCountNumber) return [];
    const dates = [];
    const base = new Date(form.start_date);
    const days = getDaysByType(form.interest_type);
    for (let i = 0; i < installmentsCountNumber; i++) {
      const d = new Date(base);
      d.setDate(d.getDate() + days * i);
      dates.push(d.toISOString().slice(0, 10));
    }
    return dates;
  }

  useEffect(() => {
    const preview = generateDatesPreview();
    if (!manualDates) {
      setPlannedDates(preview);
    }
  }, [form.start_date, form.installments_count, form.interest_type]);

  async function load() {
    setLoading(true);
    const params = filterStatus ? `?status=${encodeURIComponent(filterStatus)}` : "";
    try {
      const res = await apiFetch(`/api/loans${params}`);
      setLoans(res);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [filterStatus]);

  async function handleCreate(e) {
    e.preventDefault();
    try {
      const principal = Number(form.principal);
      const installmentsCount = Number(form.installments_count);
      const interestRate = Number(form.interest_rate);
      const interestFactorLocal = getInterestFactorByType(form.interest_type);
      const effectiveRatePerInstallmentLocal = interestRate * interestFactorLocal;
      const totalInterestLocal =
        principal * (effectiveRatePerInstallmentLocal / 100) * installmentsCount;
      const totalWithInterestLocal = principal + totalInterestLocal;
      const autoInstallmentValueLocal =
        installmentsCount > 0 ? totalWithInterestLocal / installmentsCount : 0;
      const body = {
        ...form,
        client_id: Number(form.client_id),
        principal,
        interest_rate: interestRate,
        installments_count: installmentsCount,
        installment_value: form.installment_value
          ? Number(form.installment_value)
          : autoInstallmentValueLocal
      };
      if (manualDates && plannedDates.length === installmentsCount) {
        body.installment_dates = plannedDates;
      }
      const created = await apiFetch("/api/loans", {
        method: "POST",
        body: JSON.stringify(body)
      });
      await load();
      setForm({
        ...form,
        client_id: "",
        principal: "",
        installment_value: ""
      });
      await openLoan(created);
    } catch (err) {
      alert(err.message);
    }
  }

  async function markInstallmentPaid(inst) {
    const valueStr = window.prompt(
      `Informe o valor pago na parcela #${inst.number}`,
      (inst.original_amount + inst.interest_amount + inst.penalty_amount - inst.paid_amount).toFixed(2)
    );
    if (!valueStr) return;
    const amount = Number(valueStr.replace(",", "."));
    if (!amount || amount <= 0) return;
    try {
      await apiFetch(`/api/installments/${inst.id}/pay`, {
        method: "PATCH",
        body: JSON.stringify({ amount })
      });
      if (selected) {
        const res = await apiFetch(`/api/loans/${selected.id}`);
        setInstallments(res.installments);
        await load();
      }
    } catch (err) {
      alert(err.message);
    }
  }

  async function recalcInstallment(inst) {
    try {
      await apiFetch(`/api/installments/${inst.id}/recalculate`, {
        method: "POST"
      });
      if (selected) {
        const res = await apiFetch(`/api/loans/${selected.id}`);
        setInstallments(res.installments);
      }
    } catch (err) {
      alert(err.message);
    }
  }

  function updateInstallmentDueDate(id, value) {
    setInstallments((prev) => prev.map((inst) => (inst.id === id ? { ...inst, due_date: value } : inst)));
  }

  async function saveInstallmentDate(inst) {
    try {
      await apiFetch(`/api/installments/${inst.id}`, {
        method: "PATCH",
        body: JSON.stringify({ due_date: inst.due_date })
      });
      if (selected) {
        const res = await apiFetch(`/api/loans/${selected.id}`);
        setInstallments(res.installments);
      }
    } catch (err) {
      alert(err.message);
    }
  }

  return (
    <div className="layout-main">
      <div className="panel">
        <div className="panel-header">
          <div className="panel-title">Empréstimos</div>
          <div className="panel-subtitle">{loans.length} registros</div>
        </div>
        <div className="toolbar">
          {["", "Ativo", "Quitado", "Atrasado", "Cancelado"].map((st) => (
            <button
              key={st || "todos"}
              className={`pill ${filterStatus === st ? "active" : ""}`}
              onClick={() => setFilterStatus(st)}
            >
              {st || "Todos"}
            </button>
          ))}
        </div>
        {loading && <div>Carregando...</div>}
        {error && <div>Erro: {error}</div>}
        <div style={{ overflowX: "auto" }}>
          <table className="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Cliente</th>
                <th>Valor</th>
                <th>Parcelas</th>
                <th>Juros</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {loans.map((l) => (
                <tr key={l.id}>
                  <td className="td-right">{l.id}</td>
                  <td>{l.client_name}</td>
                  <td className="td-right">R$ {l.principal.toFixed(2)}</td>
                  <td className="td-right">{l.installments_count} x</td>
                  <td>
                    {l.interest_rate}% {l.interest_type}
                  </td>
                  <td>
                    <StatusTag value={l.status} />
                  </td>
                  <td className="td-actions">
                    <button className="btn btn-sm btn-secondary" onClick={() => onOpenLoan(l.id)}>
                      Detalhes
                    </button>
                  </td>
                </tr>
              ))}
              {loans.length === 0 && !loading && (
                <tr>
                  <td colSpan={7}>Nenhum empréstimo cadastrado.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      <div className="panel">
        <div className="panel-header">
          <div className="panel-title">Novo empréstimo</div>
        </div>
        <form onSubmit={handleCreate}>
          <div className="form-row">
            <div className="form-group">
              <label>ID do cliente</label>
              <input
                value={form.client_id}
                onChange={(e) => setForm({ ...form, client_id: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Valor emprestado</label>
              <input
                type="number"
                step="0.01"
                value={form.principal}
                onChange={(e) => setForm({ ...form, principal: e.target.value })}
                required
              />
            </div>
          </div>
          <div className="form-row" style={{ marginTop: "0.5rem" }}>
            <div className="form-group">
              <label>Tipo de juros</label>
              <select
                value={form.interest_type}
                onChange={(e) => setForm({ ...form, interest_type: e.target.value })}
              >
                <option value="diario">Diário</option>
                <option value="semanal">Semanal</option>
                <option value="quinzenal">Quinzenal</option>
                <option value="mensal">Mensal</option>
              </select>
            </div>
            <div className="form-group">
              <label>% Juros</label>
              <input
                type="number"
                step="0.01"
                value={form.interest_rate}
                onChange={(e) => setForm({ ...form, interest_rate: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Qtd. parcelas</label>
              <input
                type="number"
                value={form.installments_count}
                onChange={(e) => setForm({ ...form, installments_count: e.target.value })}
                required
              />
            </div>
          </div>
          <div className="form-row" style={{ marginTop: "0.5rem" }}>
            <div className="form-group">
              <label>Valor da parcela (opcional)</label>
              <input
                type="number"
                step="0.01"
                value={form.installment_value}
                onChange={(e) => setForm({ ...form, installment_value: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label>Data de início</label>
              <input
                type="date"
                value={form.start_date}
                onChange={(e) => setForm({ ...form, start_date: e.target.value })}
                required
              />
            </div>
          </div>
          <div className="card" style={{ marginTop: "0.75rem" }}>
            <div className="card-title">Resumo automático (juros por período selecionado)</div>
            <div className="card-subtitle">
              Preencha valor e quantidade de parcelas para ver o cálculo sugerido.
            </div>
            <div className="form-row" style={{ marginTop: "0.5rem" }}>
              <div className="form-group">
                <label>Total de juros</label>
                <div>R$ {totalInterest.toFixed(2)}</div>
              </div>
              <div className="form-group">
                <label>Total com juros</label>
                <div>R$ {totalWithInterest.toFixed(2)}</div>
              </div>
              <div className="form-group">
                <label>Parcela sugerida</label>
                <div>R$ {autoInstallmentValue.toFixed(2)}</div>
              </div>
            </div>
            {plannedDates.length > 0 && (
              <div style={{ marginTop: "0.5rem", fontSize: "0.8rem" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <strong>Vencimentos</strong>
                  <div>
                    <button
                      type="button"
                      className="btn btn-sm btn-secondary"
                      onClick={() => {
                        setManualDates(false);
                        setPlannedDates(generateDatesPreview());
                      }}
                    >
                      Usar datas automáticas
                    </button>
                  </div>
                </div>
                <div className="form-row" style={{ marginTop: "0.5rem" }}>
                  {plannedDates.map((date, index) => (
                    <div key={index} className="form-group" style={{ minWidth: 160 }}>
                      <label>Parcela {index + 1}</label>
                      <input
                        type="date"
                        value={date || ""}
                        onChange={(e) => {
                          const arr = [...plannedDates];
                          arr[index] = e.target.value;
                          setPlannedDates(arr);
                          setManualDates(true);
                        }}
                        required
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          <div className="form-actions">
            <button className="btn btn-primary" type="submit">
              Criar empréstimo
            </button>
          </div>
        </form>
        {/* detalhes agora abrem em página dedicada */}
      </div>
    </div>
  );
}
