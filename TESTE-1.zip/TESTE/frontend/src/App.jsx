import React, { useState } from "react";
import { AuthProvider, useAuth } from "./AuthContext.jsx";
import LoginPage from "./LoginPage.jsx";
import DashboardPage from "./DashboardPage.jsx";
import ClientsPage from "./ClientsPage.jsx";
import LoansPage from "./LoansPage.jsx";
import SettingsPage from "./SettingsPage.jsx";
import BillingPage from "./BillingPage.jsx";
import LoanDetailsPage from "./LoanDetailsPage.jsx";

function Layout() {
  const { user, loading, logout } = useAuth();
  const [page, setPage] = useState("dashboard");
  const [selectedLoanId, setSelectedLoanId] = useState(null);

  if (loading) return <div>Carregando sessão...</div>;
  if (!user) return <LoginPage />;

  function renderPage() {
    if (page === "dashboard") return <DashboardPage />;
    if (page === "clients") return <ClientsPage />;
    if (page === "loans")
      return (
        <LoansPage
          onOpenLoan={(loanId) => {
            setSelectedLoanId(loanId);
            setPage("loanDetails");
          }}
        />
      );
    if (page === "billing") return <BillingPage />;
    if (page === "settings") return <SettingsPage />;
    if (page === "loanDetails")
      return <LoanDetailsPage loanId={selectedLoanId} onBack={() => setPage("loans")} />;
    return <DashboardPage />;
  }

  return (
    <div className="app-container">
      <aside className="sidebar">
        <div className="sidebar-title">Gestor de Empréstimos</div>
        <nav className="sidebar-nav">
          <button
            className={page === "dashboard" ? "active" : ""}
            onClick={() => setPage("dashboard")}
          >
            Dashboard
          </button>
          <button className={page === "clients" ? "active" : ""} onClick={() => setPage("clients")}>
            Clientes
          </button>
          <button className={page === "loans" ? "active" : ""} onClick={() => setPage("loans")}>
            Empréstimos
          </button>
          <button className={page === "billing" ? "active" : ""} onClick={() => setPage("billing")}>
            Cobrança
          </button>
          <button
            className={page === "settings" ? "active" : ""}
            onClick={() => setPage("settings")}
          >
            Configurações
          </button>
        </nav>
        <div className="sidebar-footer">
          <div>{user.email}</div>
          <div style={{ marginTop: "0.25rem", display: "flex", gap: "0.4rem" }}>
            <span className="tag">{user.role === "admin" ? "Administrador" : "Usuário"}</span>
            <span className="tag">{(user.plan_days ?? 30) + " dias"}</span>
          </div>
          <button
            className="btn btn-sm btn-secondary"
            style={{ marginTop: "0.5rem" }}
            onClick={logout}
          >
            Sair
          </button>
        </div>
      </aside>
      <main className="content">
        <div className="content-header">
          <div className="page-title">
            {page === "dashboard" && "Visão geral"}
            {page === "clients" && "Gestão de clientes"}
            {page === "loans" && "Gestão de empréstimos"}
            {page === "billing" && "Gestão de cobranças"}
            {page === "settings" && "Configurações"}
          </div>
          <div className="user-badge">
            <span>{user.name}</span>
            <div style={{ display: "flex", gap: "0.4rem" }}>
              <span className="tag">{user.role === "admin" ? "Administrador" : "Usuário"}</span>
              <span className="tag">{(user.plan_days ?? 30) + " dias"}</span>
            </div>
          </div>
        </div>
        {renderPage()}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Layout />
    </AuthProvider>
  );
}
