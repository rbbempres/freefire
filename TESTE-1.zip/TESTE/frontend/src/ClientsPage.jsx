import React, { useEffect, useState } from "react";
import { useAuth } from "./AuthContext.jsx";

export default function ClientsPage() {
  const { apiFetch, user } = useAuth();
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState(null);
  const [historyModal, setHistoryModal] = useState({ visible: false, client: null, items: [], loading: false, outstanding: 0 });
  const [whatsModal, setWhatsModal] = useState({
    visible: false,
    client: null,
    loans: [],
    selectedLoanId: null
  });

  const [form, setForm] = useState({
    name: "",
    document: "",
    phone: "",
    address: "",
    notes: ""
  });

  async function load() {
    setLoading(true);
    setError("");
    try {
      const res = await apiFetch("/api/clients");
      setClients(res);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function openHistoryModal(client) {
    setHistoryModal({ visible: true, client, items: [], loading: true, outstanding: 0 });
    try {
      const items = await apiFetch(`/api/history/client/${client.id}`);
      const filtered = items.filter((h) => {
        if (h.entity_type === "installment" && h.action === "pay") return true;
        if (h.entity_type === "loan" && (h.action === "create" || h.action === "update")) return true;
        if (h.entity_type === "client" && h.action === "update") return true;
        return false;
      });
      const totalRes = await apiFetch(`/api/clients/${client.id}/outstanding`);
      setHistoryModal({ visible: true, client, items: filtered, loading: false, outstanding: Number(totalRes.outstanding || 0) });
    } catch (err) {
      alert(err.message);
      setHistoryModal({ visible: true, client, items: [], loading: false, outstanding: 0 });
    }
  }

  function closeHistoryModal() {
    setHistoryModal({ visible: false, client: null, items: [], loading: false });
  }

  function renderHistoryRow(h) {
    const created = new Date(h.created_at).toLocaleString("pt-BR");
    let desc = "";
    let emoji = "•";
    const actor = h.user_name ? ` (por ${h.user_name})` : "";
    try {
      const before = h.before_data ? JSON.parse(h.before_data) : null;
      const after = h.after_data ? JSON.parse(h.after_data) : null;
      if (h.entity_type === "installment" && h.action === "pay" && before && after) {
        const total = (before.original_amount || 0) + (before.interest_amount || 0) + (before.penalty_amount || 0);
        const pagoAgora = (after.paid_amount || 0) - (before.paid_amount || 0);
        const faltando = Math.max(0, total - (after.paid_amount || 0));
        const dataPag = (after.paid_at ? new Date(after.paid_at) : new Date(h.created_at))
          .toLocaleDateString("pt-BR");
        const diasMulta = Number(after.daysLate || 0);
        emoji = "💸";
        desc = `Pagou R$ ${pagoAgora.toFixed(2)} da parcela #${before.number} em ${dataPag} • multa ${diasMulta} dia(s) • Total R$ ${total.toFixed(2)} • Faltou R$ ${faltando.toFixed(2)}`;
      } else if (h.entity_type === "installment" && h.action === "update" && before && after) {
        emoji = "✏️";
        desc = `Atualização na parcela #${before.number || before.id || ""}`;
      } else if (h.entity_type === "loan" && h.action === "create") {
        emoji = "📑";
        desc = `Contrato #${h.entity_id} criado`;
      } else if (h.entity_type === "loan" && h.action === "update") {
        emoji = "✏️";
        desc = `Contrato #${h.entity_id} atualizado`;
      } else if (h.entity_type === "client" && h.action === "update") {
        emoji = "👤";
        desc = `Cliente atualizado`;
      }
    } catch {}
    const notes = h.notes ? `\nObs: ${h.notes}` : "";
    return `${created} • ${emoji} ${desc}${actor}${notes}`;
  }

  function historyItemStyle(h) {
    let color = undefined;
    try {
      if (h.entity_type === "installment" && h.action === "pay" && h.before_data && h.after_data) {
        const before = JSON.parse(h.before_data);
        const after = JSON.parse(h.after_data);
        const total = (before.original_amount || 0) + (before.interest_amount || 0) + (before.penalty_amount || 0);
        const faltando = Math.max(0, total - (after.paid_amount || 0));
        if (faltando > 0) {
          color = "red";
        }
      }
    } catch {}
    return { marginBottom: "0.4rem", whiteSpace: "pre-wrap", color };
  }

  useEffect(() => {
    load();
  }, []);

  function startEdit(client) {
    setEditing(client.id);
    setForm({
      name: client.name,
      document: client.document || "",
      phone: client.phone || "",
      address: client.address || "",
      notes: client.notes || ""
    });
  }

  function resetForm() {
    setEditing(null);
    setForm({
      name: "",
      document: "",
      phone: "",
      address: "",
      notes: ""
    });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    try {
      if (editing) {
        await apiFetch(`/api/clients/${editing}`, {
          method: "PUT",
          body: JSON.stringify(form)
        });
      } else {
        await apiFetch("/api/clients", {
          method: "POST",
          body: JSON.stringify(form)
        });
      }
      await load();
      resetForm();
    } catch (err) {
      alert(err.message);
    }
  }

  async function handleDelete(client) {
    if (user.role !== "admin") {
      alert("Apenas administradores podem excluir clientes.");
      return;
    }
    const ok = window.confirm(`Confirma excluir o cliente "${client.name}"?`);
    if (!ok) return;
    try {
      await apiFetch(`/api/clients/${client.id}`, { method: "DELETE" });
      await load();
    } catch (err) {
      alert(err.message);
    }
  }

  function sanitizePhone(phone) {
    const digits = String(phone || "").replace(/\D/g, "");
    if (!digits) return "";
    return digits.startsWith("55") ? digits : "55" + digits;
  }

  async function openWhatsModal(client) {
    if (!client.phone) {
      alert("Este cliente não possui telefone cadastrado.");
      return;
    }
    try {
      const loans = await apiFetch(`/api/clients/${client.id}/loans`);
      setWhatsModal({
        visible: true,
        client,
        loans,
        selectedLoanId: loans[0]?.id || null
      });
    } catch (err) {
      alert(err.message);
    }
  }

  function closeWhatsModal() {
    setWhatsModal({ visible: false, client: null, loans: [], selectedLoanId: null });
  }

  async function sendWhats() {
    const loanId = whatsModal.selectedLoanId;
    if (!loanId) {
      alert("Selecione um contrato para enviar.");
      return;
    }
    try {
      const res = await apiFetch(`/api/loans/${loanId}`);
      const { loan, installments } = res;
      const client = whatsModal.client;
      const lines = [];
      lines.push("Contrato de Empréstimo");
      lines.push("");
      lines.push(`Cliente: ${client.name}`);
      if (client.document) lines.push(`Documento: ${client.document}`);
      lines.push(`Telefone: ${client.phone}`);
      lines.push("");
      lines.push(
        `Valor: R$ ${Number(loan.principal).toFixed(2)} • ${loan.installments_count}x de R$ ${Number(
          loan.installment_value
        ).toFixed(2)}`
      );
      lines.push(`Juros: ${loan.interest_rate}% ${loan.interest_type}`);
      lines.push(`Início: ${loan.start_date}`);
      lines.push("");
      lines.push("Parcelas:");
      installments.forEach((inst) => {
        const totalInst = Number(inst.original_amount) + Number(inst.interest_amount);
        lines.push(
          `#${inst.number} • Venc: ${inst.due_date} • R$ ${totalInst.toFixed(2)} • Status: ${inst.status}`
        );
      });
      const textRaw = lines.join("\n");
      const text =
        textRaw.length > 3500 ? textRaw.slice(0, 3500) + "\n..." : textRaw;
      const phone = sanitizePhone(client.phone);
      if (!phone) {
        alert("Telefone inválido para WhatsApp.");
        return;
      }
      const url = `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
      window.open(url, "_blank");
      closeWhatsModal();
    } catch (err) {
      alert(err.message);
    }
  }

  return (
    <div className="layout-main">
      <div className="panel">
        <div className="panel-header">
          <div className="panel-title">Clientes</div>
          <div className="panel-subtitle">{clients.length} cadastrados</div>
        </div>
        {loading && <div>Carregando...</div>}
        {error && <div>Erro: {error}</div>}
        <div style={{ overflowX: "auto" }}>
          <table className="table">
            <thead>
              <tr>
                <th>Nome</th>
                <th>Documento</th>
                <th>Telefone</th>
                <th>Empréstimos</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {clients.map((c) => (
                <tr key={c.id}>
                  <td>{c.name}</td>
                  <td>{c.document}</td>
                  <td>{c.phone}</td>
                  <td className="td-right">{c.loans_count}</td>
                  <td className="td-actions">
                    <button className="btn btn-sm btn-secondary" onClick={() => startEdit(c)}>
                      Editar
                    </button>{" "}
                    <button className="btn btn-sm btn-secondary" onClick={() => openHistoryModal(c)}>
                      Histórico
                    </button>{" "}
                    <button className="btn btn-sm btn-primary" onClick={() => openWhatsModal(c)}>
                      WhatsApp
                    </button>{" "}
                    <button className="btn btn-sm btn-danger" onClick={() => handleDelete(c)}>
                      Excluir
                    </button>
                  </td>
                </tr>
              ))}
              {clients.length === 0 && !loading && (
                <tr>
                  <td colSpan={5}>Nenhum cliente cadastrado ainda.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      {historyModal.visible && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.4)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 9999
          }}
        >
          <div className="panel" style={{ maxWidth: 600, width: "90%" }}>
            <div className="panel-header">
              <div className="panel-title">Histórico do cliente</div>
              <div className="panel-subtitle">
                {historyModal.client ? historyModal.client.name : ""}
              </div>
            </div>
            <div className="card" style={{ marginTop: "0.5rem" }}>
              <div className="form-row">
                <div className="form-group">
                  <label>Falta pagar</label>
                  <div>
                    R$ {Number(historyModal.outstanding || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                </div>
              </div>
            </div>
            {historyModal.loading && <div>Carregando histórico...</div>}
            {!historyModal.loading && (
              <div>
                {historyModal.items.length === 0 && <div>Nenhum evento registrado.</div>}
                {historyModal.items.length > 0 && (
                  <ul style={{ paddingLeft: "1rem" }}>
                    {historyModal.items.map((h) => (
                      <li key={h.id} style={historyItemStyle(h)}>
                        {renderHistoryRow(h)}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}
            <div className="form-actions">
              <button className="btn btn-secondary" onClick={closeHistoryModal}>
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
      <div className="panel">
        <div className="panel-header">
          <div className="panel-title">{editing ? "Editar cliente" : "Novo cliente"}</div>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Nome completo</label>
            <input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
            />
          </div>
          <div className="form-row" style={{ marginTop: "0.5rem" }}>
            <div className="form-group">
              <label>CPF / Documento</label>
              <input
                value={form.document}
                onChange={(e) => setForm({ ...form, document: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label>Telefone / WhatsApp</label>
              <input
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
              />
            </div>
          </div>
          <div className="form-group" style={{ marginTop: "0.5rem" }}>
            <label>Endereço</label>
            <input
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
            />
          </div>
          <div className="form-group" style={{ marginTop: "0.5rem" }}>
            <label>Observações</label>
            <textarea
              rows={3}
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
            />
          </div>
          <div className="form-actions">
            <button className="btn btn-primary" type="submit">
              {editing ? "Salvar alterações" : "Cadastrar cliente"}
            </button>
            {editing && (
              <button type="button" className="btn btn-secondary" onClick={resetForm}>
                Cancelar
              </button>
            )}
          </div>
        </form>
      </div>
      {whatsModal.visible && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.4)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 9999
          }}
        >
          <div className="panel" style={{ maxWidth: 420, width: "90%" }}>
            <div className="panel-header">
              <div className="panel-title">Enviar contrato via WhatsApp</div>
            </div>
            <div className="form-group">
              <label>Contrato</label>
              <select
                value={whatsModal.selectedLoanId || ""}
                onChange={(e) =>
                  setWhatsModal({
                    ...whatsModal,
                    selectedLoanId: Number(e.target.value)
                  })
                }
              >
                {whatsModal.loans.map((l) => (
                  <option key={l.id} value={l.id}>
                    #{l.id} • R$ {Number(l.principal).toFixed(2)} • {l.installments_count}x •{" "}
                    {l.interest_rate}% {l.interest_type}
                  </option>
                ))}
              </select>
            </div>
            <div className="form-actions">
              <button className="btn btn-primary" onClick={sendWhats}>
                Enviar WhatsApp
              </button>
              <button className="btn btn-secondary" onClick={closeWhatsModal}>
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
