import React, { createContext, useContext, useEffect, useState } from "react";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("gestor-auth");
    if (stored) {
      const parsed = JSON.parse(stored);
      setUser(parsed.user);
      setToken(parsed.token);
    }
    setLoading(false);
  }, []);

  function saveAuth(data) {
    setUser(data.user);
    setToken(data.token);
    localStorage.setItem("gestor-auth", JSON.stringify(data));
  }

  function logout() {
    setUser(null);
    setToken(null);
    localStorage.removeItem("gestor-auth");
  }

  async function apiFetch(path, options = {}) {
    const headers = options.headers ? { ...options.headers } : {};
    headers["Content-Type"] = "application/json";
    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }
    const res = await fetch(path, {
      ...options,
      headers
    });
    if (res.status === 401 || res.status === 403) {
      logout();
    }
    if (!res.ok) {
      let message = "Erro na requisição";
      try {
        const data = await res.json();
        if (data && data.message) {
          message = data.message;
        }
      } catch {
        // ignore
      }
      throw new Error(message);
    }
    if (res.status === 204) {
      return null;
    }
    return res.json();
  }

  const value = { user, token, loading, saveAuth, logout, apiFetch };
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}

